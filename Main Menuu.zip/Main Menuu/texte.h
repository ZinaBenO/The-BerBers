#include <SDL/SDL_ttf.h> 
#include <SDL/SDL.h>

typedef struct
{
	SDL_Rect position;
	TTF_Font *font; //determiner police et taille
	SDL_Surface *surfaceT; //pour afficher 
	SDL_Color texteCOLOR; //choisir couleur
	char texte[50]; 
}texte;

void initTEXTE(texte *t);
void displayTEXTE(SDL_Surface *ecran,texte t);
void liberertexte(texte t);

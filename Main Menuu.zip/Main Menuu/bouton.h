#ifndef Image_H
#define Image_H
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#define SCREEN_W 800
#define SCREEN_H 400
#include<stdio.h>
#include<stdlib.h>
struct Image{
SDL_Rect pos1;
SDL_Rect pos2;
SDL_Surface *img;
};
typedef struct Image Image ;
void initBouton(Image *Btn);
void initBouton1(Image *Btn1);
void initBouton2(Image *Btn2);
void initBoutonrose(Image *Btn);
void initBouton1rose(Image *Btn);
void initBouton2rose(Image *Btn);
void initBoutonreturn(Image *Btnre);
void initBoutonreturn2(Image *Btnre);
void initBoutonsound(Image *Btno);
void initBoutonfull(Image *Btnf);
void initBoutonfullr(Image *Btnf);
void initBoutonplus(Image *Btnf);
void initBoutonmoin(Image *Btnf);
void initBoutonplusr(Image *Btnf);
void initBoutonmoinr(Image *Btnf);
void initniv1(Image *Btnre);
void initniv2(Image *Btnre);
void initniv3(Image *Btnre);

void liberbtn(Image A);
void afficherbtn(Image p , SDL_Surface *screen);
#endif 


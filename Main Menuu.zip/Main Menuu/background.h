#ifndef Image_H
#define Image_H
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#define SCREEN_W 800
#define SCREEN_H 400
#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL_ttf.h>
struct Image{
SDL_Rect pos1;
SDL_Rect pos2;
SDL_Surface *img;
};
typedef struct Image Image ;
void initBackgound(Image *Backg);
void initBackgound1(Image *Backg);
void initBackgound2(Image *Backg);
void initBackgound3(Image *Backg);
void initBackgound4(Image *Backg);
void initBackgoundniveau(Image *Backg);
void initBackgoundoption(Image *Backg);
void animation(SDL_Surface *ecran);
void ajustervolume(int *newvolume,int i);
void afficher(Image p , SDL_Surface *screen);
void libererbg(Image A);
#endif 

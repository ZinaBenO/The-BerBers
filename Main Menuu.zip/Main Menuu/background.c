#include"background.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>



void initBackgound(Image *Backg){
Backg->img=IMG_Load("Main Menuu.jpg");
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1919;
Backg->pos1.y=1078;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}
void initBackgound1(Image *Backg){
Backg->img=IMG_Load("1.jpg");
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}
void initBackgound2(Image *Backg){
Backg->img=IMG_Load("2.jpg");
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}
void initBackgound3(Image *Backg){
Backg->img=IMG_Load("3.jpg");
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}
void initBackgound4(Image *Backg){
Backg->img=IMG_Load("4.jpg");
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}
void initBackgoundniveau(Image *Backg){
Backg->img=IMG_Load("Levels.jpg");
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}
void initBackgoundoption(Image *Backg){
Backg->img=IMG_Load("Optionss.jpg");  
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}

void initBackgoundexit(Image *Backg){
Backg->img=IMG_Load("do u rlly want to exitt.jpg");  
if(Backg->img==NULL){
return;
}
Backg->pos1.x=1920;
Backg->pos1.y=1081;
Backg->pos1.w=Backg->img->w;
Backg->pos1.h=Backg->img->h;
Backg->pos2.x=0;
Backg->pos2.y=0;
Backg->pos2.w=Backg->img->w;
Backg->pos2.h=Backg->img->h;

}

void animation(SDL_Surface *ecran)
{

SDL_Surface *background;
SDL_Rect posbackground;
posbackground.x=posbackground.y=0;
char e[30];



    for(int i=0;i<13;i++)
    

    {
        sprintf(e,"loading/%d.jpg",i);//pour inseré une chaine
                SDL_BlitSurface(IMG_Load(e), NULL, ecran, &posbackground);
          SDL_Flip(ecran);
          SDL_Delay(125); 
         
	}

}
void ajustervolume(int *newvolume,int i){
(*newvolume)+=i;
if (*newvolume < 0){
	*newvolume = 0;
}
else if (*newvolume > SDL_MIX_MAXVOLUME){
	*newvolume = SDL_MIX_MAXVOLUME;
}
}








void afficher(Image p , SDL_Surface *screen){
SDL_BlitSurface(p.img,NULL,screen,NULL);
}
void libererbg(Image A){
SDL_FreeSurface(A.img);
}

#include <SDL/SDL.h>
#include<SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include"background.h"
#include"bouton.h"
#include"texte.h"
#include <SDL/SDL_ttf.h>
int main ( int argc, char** argv )
{
SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO);
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,1024);//t7ellk bafflouet el pc
int *vm;
texte t;
Image bkg,bkg1,bkg2,bkg3,bkg4,bkgn,bkgo,bkex;
Image btn;//declartion de btn bleu
Image btn1;
Image btn2;
Image btnr;//declartion de btn rose
Image btnr1;
Image btnr2;
Image btnre;
Image btnre2;
Image Btno;
Image Btnf;
Image btnfr;
Image plus,moin,plusr,moinr;
Image niv1;
Image niv2;
Image niv3;
int play=0;
SDL_Surface *background;
SDL_Rect posbackground;
Mix_Chunk *son;
son=Mix_LoadWAV("dhia.wav");
if(son==NULL)
printf("%s",Mix_GetError());

Mix_Music*musique;
SDL_Event event;//elle detecte ttes les informations 
SDL_Event event1;
SDL_Event event2;
SDL_Surface *ecran;//pointeur 3al ecran el ka7la 
int quitter = 1;
//bch ta3melkk ecran ka7la d7iss
ecran = SDL_SetVideoMode(960, 535,  32,SDL_HWSURFACE | SDL_DOUBLEBUF);
	if ( ecran == NULL )
	{
		fprintf(stderr, "Echec de creation de la fenetre de 300*300: %s.\n", SDL_GetError());
		return 1;
	}

initBackgound(&bkg);
initBackgound1(&bkg1);
initBackgound2(&bkg2);
initBackgound3(&bkg3);
initBackgound4(&bkg4);
initBackgoundniveau(&bkgn);
initBackgoundoption(&bkgo);
initBackgoundexit(&bkex);
initBouton(&btn);//appelle de bton bleu
initBouton1(&btn1);
initBouton2(&btn2);
initBoutonrose(&btnr);//appelle btn rose
initBouton1rose(&btnr1);
initBouton2rose(&btnr2);
initBoutonreturn(&btnre);
initBoutonreturn2(&btnre2);
initBoutonsound(&Btno);
initBoutonfull(&Btnf);
initBoutonfullr(&btnfr);
initBoutonplus(&plus);
initBoutonmoin(&moin);
initBoutonplusr(&plusr);
initBoutonmoinr(&moinr);
initniv1(&niv1);
initniv2(&niv2);
initniv3(&niv3);
initTEXTE(&t);
musique=Mix_LoadMUS("song.mp3");
Mix_PlayMusic(musique,-1);
animation(ecran);
while(quitter) 
{
displayTEXTE(&ecran,t);
afficher(bkg,ecran);
/*afficher(bkg1,ecran);
afficher(bkg2,ecran);
afficher(bkg3,ecran);
afficher(bkg4,ecran);*/
afficherbtn(btn,ecran);
afficherbtn(btn1,ecran);
afficherbtn(btn2,ecran);
displayTEXTE(&ecran,t);
SDL_PollEvent(&event);
int p=1;

switch (event.type){
		case SDL_QUIT: quitter = 0;
        	break;
                //ya7ser taille mtaa btn
		case SDL_MOUSEMOTION://appele y5ali loun btn yetbdel
			if(event.motion.x>=btn.pos2.x && event.motion.x<=btn.pos2.x+btn.pos2.w &&event.motion.y>=btn.pos2.y&& event.motion.y<=btn.pos2.y+btn.pos2.h)
				afficherbtn(btnr,ecran);
                
                	if(event.motion.x>=350 && event.motion.x<=602 &&event.motion.y>=300&& event.motion.y<=357)
				afficherbtn(btnr1,ecran);

                 	if(event.motion.x>=btn2.pos2.x && event.motion.x<=btn2.pos2.x+btn2.pos2.w &&event.motion.y>=btn2.pos2.y&& event.motion.y<=btn2.pos2.y+btn2.pos2.h)
				afficherbtn(btnr2,ecran);

                break;
		case SDL_MOUSEBUTTONDOWN:
			if(event.motion.x>=btn.pos2.x && event.motion.x<=btn.pos2.x+btn.pos2.w &&event.motion.y>=btn.pos2.y&& event.motion.y<=btn.pos2.y+btn.pos2.h)
				if (event.button.button==SDL_BUTTON_LEFT){
					p=1;
					Mix_PlayChannel(-1,son,0);
					while(p==1){
			
						afficher(bkgn,ecran);
						afficherbtn(btnre,ecran);
						afficherbtn(niv1,ecran);
						afficherbtn(niv2,ecran);
						afficherbtn(niv3,ecran);
						
						SDL_PollEvent(&event1);
						switch (event1.type){
							case SDL_QUIT: p = 0; 
							break;
							case SDL_MOUSEMOTION:
								if(event1.motion.x>=btnre.pos2.x && event1.motion.x<=btnre.pos2.x+btnre.pos2.w &&event1.motion.y>=btnre.pos2.y&& event1.motion.y<=btnre.pos2.y+btnre.pos2.h){
									afficherbtn(btnre2,ecran);
									
								}
							break;
							case SDL_MOUSEBUTTONDOWN:
								if(event1.button.button==SDL_BUTTON_LEFT && event1.motion.x>=btnre.pos2.x && event1.motion.x<=btnre.pos2.x+btnre.pos2.w &&event1.motion.y>=btnre.pos2.y&& event1.motion.y<=btnre.pos2.y+btnre.pos2.h){
									Mix_PlayChannel(-1,son,0);
									p=0;
								}
							case SDL_KEYDOWN:
								if(event1.key.keysym.sym==SDLK_ESCAPE){
									p=0;
								}
							break;
							
								
							
								
						}
					
						SDL_Flip(ecran);
					
					}
				}
                	if(event.motion.x>=350 && event.motion.x<=602 &&event.motion.y>=300&& event.motion.y<=357)
				if (event.button.button==SDL_BUTTON_LEFT){
					Mix_PlayChannel(-1,son,0);
					
					while(p==1){
						afficher(bkgo,ecran);
						afficherbtn(btnre,ecran);
						afficherbtn(Btno,ecran);//sound options
						afficherbtn(plus,ecran);
						afficherbtn(moin,ecran);
						afficherbtn(Btnf,ecran);//full screan
						
						SDL_PollEvent(&event2);
						switch (event2.type){
							case SDL_QUIT: p = 0;
        						break;
							case SDL_MOUSEMOTION:
								if(event2.motion.x>=btnre.pos2.x && event2.motion.x<=btnre.pos2.x+btnre.pos2.w &&event2.motion.y>=btnre.pos2.y&& event2.motion.y<=btnre.pos2.y+btnre.pos2.h){
									afficherbtn(btnre2,ecran);
								}
								if(event2.motion.x>=Btnf.pos2.x && event2.motion.x<=Btnf.pos2.x+Btnf.pos2.w &&event2.motion.y>=Btnf.pos2.y&& event2.motion.y<=Btnf.pos2.y+Btnf.pos2.h){
									afficherbtn(btnfr,ecran);
								}
								if(event2.motion.x>=plus.pos2.x && event2.motion.x<=plus.pos2.x+plus.pos2.w &&event2.motion.y>=plus.pos2.y&& event2.motion.y<=plus.pos2.y+plus.pos2.h){
									afficherbtn(plusr,ecran);
								}
								if(event2.motion.x>=moin.pos2.x && event2.motion.x<=moin.pos2.x+moin.pos2.w &&event2.motion.y>=moin.pos2.y&& event2.motion.y<=moin.pos2.y+moin.pos2.h){
									afficherbtn(moinr,ecran);
								}
							break;
							case SDL_MOUSEBUTTONDOWN:
								if(event2.button.button==SDL_BUTTON_LEFT && event2.motion.x>=btnre.pos2.x && event2.motion.x<=btnre.pos2.x+btnre.pos2.w &&event2.motion.y>=btnre.pos2.y&& event2.motion.y<=btnre.pos2.y+btnre.pos2.h){
									Mix_PlayChannel(-1,son,0);
									p=0;
									}
						
							case SDL_KEYDOWN:
								if(event2.key.keysym.sym==SDLK_ESCAPE){
									p=0;
								}
								if(event2.key.keysym.sym==SDLK_RIGHT){
									afficherbtn(plusr,ecran);
		        						//ajustervolume(&vm,50); // Increase volume
									//Mix_Volume(-1,vm+50);
								}
								if(event2.key.keysym.sym==SDLK_LEFT){
									afficherbtn(moinr,ecran);
		        						//ajustervolume(&vm,-50); // Increase volume
									//Mix_Volume(-1,vm-50);
								}
							break;
							
							
						}
						SDL_Flip(ecran);
					}	
					
				}
                 	if(event.motion.x>=btn2.pos2.x && event.motion.x<=btn2.pos2.x+btn2.pos2.w &&event.motion.y>=btn2.pos2.y&& event.motion.y<=btn2.pos2.y+btn2.pos2.h)
				if (event.button.button==SDL_BUTTON_LEFT){
					Mix_PlayChannel(-1,son,0);
					quitter=0 ;
				}

                break;

		
			
}




SDL_Flip(ecran);//t refraichi l ecran
}

libererbg(bkg);

libererbtn(btn);
libererbtn(btn1);
libererbtn(btn2);
libererbtn(btnr);
libererbtn(btnr1);
libererbtn(btnr2);
libererbtn(btnre);
libererbtn(niv1);
liberertexte(t);
Mix_FreeChunk(son);
Mix_FreeMusic(musique);
Mix_CloseAudio();


SDL_Quit();
}



#include"background.h"
#include"bouton.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
void initBouton(Image *Btn)
{
Btn->img=IMG_Load("Play.png");
if(Btn->img==NULL){
return;
}
Btn->pos1.x=0;
Btn->pos1.y=0;
Btn->pos1.w=Btn->img->w;
Btn->pos1.h=Btn->img->h;
Btn->pos2.x=380;
Btn->pos2.y=202;
Btn->pos2.w=Btn->img->w;
Btn->pos2.h=Btn->img->h;

}

void initBouton1(Image *Btn1)
{
Btn1->img=IMG_Load("Options.png");
if(Btn1->img==NULL)
{
return;
}
Btn1->pos1.x=0;
Btn1->pos1.y=0;
Btn1->pos1.w=Btn1->img->w;
Btn1->pos1.h=Btn1->img->h;
Btn1->pos2.x=380;
Btn1->pos2.y=300;
Btn1->pos2.w=Btn1->img->w;
Btn1->pos2.h=Btn1->img->h;

}

void initBouton2(Image *Btn2)
{
Btn2->img=IMG_Load("Exit.png");
if(Btn2->img==NULL){
return;
}
Btn2->pos1.x=0;
Btn2->pos1.y=0;
Btn2->pos1.w=Btn2->img->w;
Btn2->pos1.h=Btn2->img->h;
Btn2->pos2.x=380;
Btn2->pos2.y=390;
Btn2->pos2.w=Btn2->img->w;
Btn2->pos2.h=Btn2->img->h;
}

void initBoutonrose(Image *Btn)
{
Btn->img=IMG_Load("Play selected.png");
if(Btn->img==NULL){
return;
}
Btn->pos1.x=0;
Btn->pos1.y=0;
Btn->pos1.w=Btn->img->w;
Btn->pos1.h=Btn->img->h;
Btn->pos2.x=380;
Btn->pos2.y=192;
Btn->pos2.w=Btn->img->w;
Btn->pos2.h=Btn->img->h;

}

void initBouton1rose(Image *Btn1)
{
Btn1->img=IMG_Load("Options selected.png");
if(Btn1->img==NULL)
{
return;
}
Btn1->pos1.x=0;
Btn1->pos1.y=0;
Btn1->pos1.w=Btn1->img->w;
Btn1->pos1.h=Btn1->img->h;
Btn1->pos2.x=380;
Btn1->pos2.y=300;
Btn1->pos2.w=Btn1->img->w;
Btn1->pos2.h=Btn1->img->h;

}
void initBouton2rose(Image *Btn2)
{
Btn2->img=IMG_Load("Exit selected.png");
if(Btn2->img==NULL){
return;
}
Btn2->pos1.x=0;
Btn2->pos1.y=0;
Btn2->pos1.w=Btn2->img->w;
Btn2->pos1.h=Btn2->img->h;
Btn2->pos2.x=380;
Btn2->pos2.y=390;
Btn2->pos2.w=Btn2->img->w;
Btn2->pos2.h=Btn2->img->h;
}
void initBoutonreturn(Image *Btnre)
{
Btnre->img=IMG_Load("Home.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=810;
Btnre->pos2.y=80;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initBoutonreturn2(Image *Btnre)
{
Btnre->img=IMG_Load("Home selected.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=810;
Btnre->pos2.y=80;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initniv1(Image *Btnre)
{
Btnre->img=IMG_Load("niveau1.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=320;
Btnre->pos2.y=200;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initniv2(Image *Btnre)
{
Btnre->img=IMG_Load("niveau2.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=520;
Btnre->pos2.y=200;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initniv3(Image *Btnre)
{
Btnre->img=IMG_Load("niveau3.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=420;
Btnre->pos2.y=350;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initBoutonsound(Image *Btno)//btn sound
{
Btno->img=IMG_Load("Sound.png");//badel lien
if(Btno->img==NULL){
return;
}
Btno->pos1.x=0;
Btno->pos1.y=0;
Btno->pos1.w=Btno->img->w;
Btno->pos1.h=Btno->img->h;
Btno->pos2.x=380;
Btno->pos2.y=172;
Btno->pos2.w=Btno->img->w;
Btno->pos2.h=Btno->img->h;

}
void initBoutonfull(Image *Btnf)//btn full scean
{
Btnf->img=IMG_Load("Full Screen.png");//badel lien
if(Btnf->img==NULL){
return;
}
Btnf->pos1.x=0;
Btnf->pos1.y=0;
Btnf->pos1.w=Btnf->img->w;
Btnf->pos1.h=Btnf->img->h;
Btnf->pos2.x=380;
Btnf->pos2.y=392;
Btnf->pos2.w=Btnf->img->w;
Btnf->pos2.h=Btnf->img->h;

}
void initBoutonfullr(Image *Btnf)//btn full scean
{
Btnf->img=IMG_Load("Full Screen selected.png");//badel lien
if(Btnf->img==NULL){
return;
}
Btnf->pos1.x=0;
Btnf->pos1.y=0;
Btnf->pos1.w=Btnf->img->w;
Btnf->pos1.h=Btnf->img->h;
Btnf->pos2.x=380;
Btnf->pos2.y=382;
Btnf->pos2.w=Btnf->img->w;
Btnf->pos2.h=Btnf->img->h;

}
void initBoutonplus(Image *Btnf)//btn full scean
{
Btnf->img=IMG_Load("plus.png");//badel lien
if(Btnf->img==NULL){
return;
}
Btnf->pos1.x=0;
Btnf->pos1.y=0;
Btnf->pos1.w=Btnf->img->w;
Btnf->pos1.h=Btnf->img->h;
Btnf->pos2.x=530;
Btnf->pos2.y=270;
Btnf->pos2.w=Btnf->img->w;
Btnf->pos2.h=Btnf->img->h;

}
void initBoutonmoin(Image *Btnf)//btn full scean
{
Btnf->img=IMG_Load("moin.png");//badel lien
if(Btnf->img==NULL){
return;
}
Btnf->pos1.x=0;
Btnf->pos1.y=0;
Btnf->pos1.w=Btnf->img->w;
Btnf->pos1.h=Btnf->img->h;
Btnf->pos2.x=390;
Btnf->pos2.y=270;
Btnf->pos2.w=Btnf->img->w;
Btnf->pos2.h=Btnf->img->h;

}
void initBoutonplusr(Image *Btnf)//btn full scean
{
Btnf->img=IMG_Load("plusr.png");//badel lien
if(Btnf->img==NULL){
return;
}
Btnf->pos1.x=0;
Btnf->pos1.y=0;
Btnf->pos1.w=Btnf->img->w;
Btnf->pos1.h=Btnf->img->h;
Btnf->pos2.x=530;
Btnf->pos2.y=270;
Btnf->pos2.w=Btnf->img->w;
Btnf->pos2.h=Btnf->img->h;

}
void initBoutonmoinr(Image *Btnf)//btn full scean
{
Btnf->img=IMG_Load("moinr.png");//badel lien
if(Btnf->img==NULL){
return;
}
Btnf->pos1.x=0;
Btnf->pos1.y=0;
Btnf->pos1.w=Btnf->img->w;
Btnf->pos1.h=Btnf->img->h;
Btnf->pos2.x=390;
Btnf->pos2.y=270;
Btnf->pos2.w=Btnf->img->w;
Btnf->pos2.h=Btnf->img->h;

}

void initBoutonYes(Image *Btnre)
{
Btnre->img=IMG_Load("Yes.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=0;
Btnre->pos2.y=0;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}

void initBoutonNo(Image *Btnre)
{
Btnre->img=IMG_Load("No.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=0;
Btnre->pos2.y=0;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initBoutonYess(Image *Btnre)
{
Btnre->img=IMG_Load("Yes selected.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=0;
Btnre->pos2.y=0;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}
void initBoutonNos(Image *Btnre)
{
Btnre->img=IMG_Load("No selected.png");
if(Btnre->img==NULL){
return;
}
Btnre->pos1.x=0;
Btnre->pos1.y=0;
Btnre->pos1.w=Btnre->img->w;
Btnre->pos1.h=Btnre->img->h;
Btnre->pos2.x=0;
Btnre->pos2.y=0;
Btnre->pos2.w=Btnre->img->w;
Btnre->pos2.h=Btnre->img->h;
}


void afficherbtn(Image p , SDL_Surface *screen){
SDL_BlitSurface(p.img,NULL,screen,&p.pos2);
}
void libererbtn(Image A){
SDL_FreeSurface(A.img);
}

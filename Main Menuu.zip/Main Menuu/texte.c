#include "texte.h"

void initTEXTE(texte *t)
{	
	TTF_Init();
	t->position.x=350;
	t->position.y=202;
	
	t->texteCOLOR.r=0;
	t->texteCOLOR.g=0;
	t->texteCOLOR.b=0;

	t->font=TTF_OpenFont("arial.ttf",30);
}

void displayTEXTE(SDL_Surface *ecran,texte t)
{
	t.surfaceT=TTF_RenderText_Solid(t.font, "Eserenity Copyright 2024", t.texteCOLOR);
	SDL_BlitSurface(t.surfaceT,NULL,ecran,&t.position);

}

void liberertexte(texte t)
{
	SDL_FreeSurface (t.surfaceT);
	TTF_CloseFont (t.font);
	TTF_Quit();
}

